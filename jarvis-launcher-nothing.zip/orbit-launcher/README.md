# Jarvis Launcher — Nothing Phone (3) edition

A HUD-style home screen with a voice assistant. **No paid API keys.** Everything runs on the phone's built-in features plus free public services.

## How it thinks (all free)

| You ask | Who handles it |
|---|---|
| Phone commands: open apps, call or text by name, timers, alarms, torch, music, volume, camera, selfie, screenshot, lock screen, Wi-Fi/Bluetooth settings, navigation, YouTube | On-device command engine (instant, offline) |
| Time, date, battery, maths ("15 percent of 2400"), read my notifications, small talk, jokes | On-device |
| "Who is…", "What is…", "Tell me about…" | DuckDuckGo and Wikipedia (free, no key); answer is spoken |
| "What's the weather?" | Open-Meteo (free, no key) using your approximate location |
| Anything open-ended | Handed to the phone's built-in Gemini, falling back to Google search |

- **Speech:** your phone's own speech recogniser and text-to-speech, preferring the offline models.
- **Network use:** only your question (or rough location, for weather) leaves the phone.

## Waking Jarvis

1. **Essential Key, double-press** (recommended). The normal single press still does what Nothing intended. You can switch to single-press wake in settings; then Jarvis takes over the key.
2. **Tap the core** on the home screen.
3. **Say "Jarvis"** (optional). This needs a **free** Picovoice AccessKey from console.picovoice.ai. No card or payment is needed.

## Install the APK

1. Download `Jarvis-Launcher.apk` to the phone and open it. Allow "Install unknown apps" for your browser or Files app when asked.
2. Open Jarvis and accept the permissions: microphone, contacts, phone, location and notifications.
3. Long-press the core to open **System Config**.

### Essential Key setup

Android protects accessibility for sideloaded apps, so this takes one extra step:

1. In **System Config**, tap **OPEN ACCESSIBILITY**, find **Jarvis (Essential Key)** and try to switch it on.
2. If it says *"Restricted setting"*:
   - Go to **Settings → Apps → Jarvis**.
   - Tap the **⋮** menu (top right), then **Allow restricted settings**.
   - Go back and switch the service on.
3. Back in System Config, tap **LEARN KEY** and press the Essential Key once.
4. Done. Double-press the Essential Key from anywhere and Jarvis pops up listening.

### Make it your home screen

In **System Config**, tap **DEFAULT HOME** and pick Jarvis.

### Notifications

On the home screen, swipe down from the top. Tap **COMMS → GRANT ACCESS**, then allow Jarvis.

## Gestures

| Do this | Get this |
|---|---|
| Double-press the Essential Key, tap the core, or say "Jarvis" | Listen |
| Tap the core while it's busy | Stop |
| Long-press the core | Settings |
| Swipe up | All apps |
| Swipe down from the top | Notifications |
| Long-press an app | App info |

## Things to try

- "Open Spotify" · "Call Amma" · "Text Rahul saying I'm 10 minutes late"
- "Set a timer for 5 minutes" · "Wake me up at 6:30 am"
- "Torch on" · "Next song" · "Volume up" · "Take a screenshot" · "Lock the phone"
- "What's the weather?" · "Who is APJ Abdul Kalam?" · "What's 18 percent of 1250?"
- "Read my notifications" · "Navigate to Kochi airport" · "Play lo-fi beats on YouTube"

## Building the APK yourself

You can build it either of two ways:

- **On GitHub (no PC):** push this folder to a GitHub repo. The included workflow (`.github/workflows/build-apk.yml`) builds the APK automatically. Download it from the repo's **Actions** tab, under **Jarvis-Launcher-apk**.
- **On a PC:** open the folder in Android Studio and press **Run**, or choose **Build → Build APK(s)**.

## Limits

- Nothing's own Essential Space AI and Gemini Nano aren't open to third-party launchers. Jarvis hands open questions to the Gemini app instead.
- Android doesn't let launchers reskin the real pull-down shade. On the home screen, Jarvis hides the system bar and shows its own themed bar and notification panel.
- Some Nothing OS versions handle the Essential Key before other apps see it. If **LEARN KEY** never reacts, the key is locked by the system on your build; use the voice or tap wake instead.
