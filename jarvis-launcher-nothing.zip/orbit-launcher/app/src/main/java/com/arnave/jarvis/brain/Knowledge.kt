package com.arnave.jarvis.brain

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.math.roundToInt

/**
 * Free, key-less lookups. Only the question itself (or your rough location, for weather)
 * is sent — nothing else from the phone.
 */
class Knowledge(private val context: Context) {

    suspend fun lookup(topic: String): String? = withContext(Dispatchers.IO) {
        duckDuckGo(topic) ?: wikipedia(topic)
    }

    private fun duckDuckGo(q: String): String? = runCatching {
        val j = JSONObject(get("https://api.duckduckgo.com/?format=json&no_html=1&skip_disambig=1&q=${enc(q)}"))
        listOf(j.optString("Answer"), j.optString("AbstractText"), j.optString("Definition"))
            .firstOrNull { it.isNotBlank() }?.let(::shorten)
    }.getOrNull()

    private fun wikipedia(q: String): String? = runCatching {
        val search = JSONObject(get("https://en.wikipedia.org/w/api.php?action=query&list=search&format=json&srlimit=1&srsearch=${enc(q)}"))
        val hits = search.getJSONObject("query").getJSONArray("search")
        if (hits.length() == 0) return@runCatching null
        val title = hits.getJSONObject(0).getString("title")
        val summary = JSONObject(get("https://en.wikipedia.org/api/rest_v1/page/summary/${enc(title.replace(' ', '_'))}"))
        summary.optString("extract").takeIf { it.isNotBlank() }?.let(::shorten)
    }.getOrNull()

    suspend fun weather(): String? = withContext(Dispatchers.IO) {
        runCatching {
            val loc = lastLocation() ?: return@runCatching null
            val url = "https://api.open-meteo.com/v1/forecast?latitude=${loc.latitude}&longitude=${loc.longitude}" +
                "&current=temperature_2m,apparent_temperature,weather_code,wind_speed_10m" +
                "&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max&forecast_days=1&timezone=auto"
            val j = JSONObject(get(url))
            val cur = j.getJSONObject("current")
            val daily = j.getJSONObject("daily")
            val now = cur.getDouble("temperature_2m").roundToInt()
            val feels = cur.getDouble("apparent_temperature").roundToInt()
            val hi = daily.getJSONArray("temperature_2m_max").getDouble(0).roundToInt()
            val lo = daily.getJSONArray("temperature_2m_min").getDouble(0).roundToInt()
            val rain = daily.getJSONArray("precipitation_probability_max").optInt(0, -1)
            buildString {
                append("It's $now degrees and ${describe(cur.getInt("weather_code"))}")
                if (feels != now) append(", feels like $feels")
                append(". Today ranges from $lo to $hi")
                if (rain >= 0) append(", with a $rain percent chance of rain")
            }
        }.getOrNull()
    }

    @SuppressLint("MissingPermission")
    private fun lastLocation(): Location? {
        val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED
        if (!granted) return null
        val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        return lm.getProviders(true).mapNotNull { runCatching { lm.getLastKnownLocation(it) }.getOrNull() }
            .maxByOrNull { it.time }
    }

    private fun describe(code: Int) = when (code) {
        0 -> "clear"
        1, 2 -> "partly cloudy"
        3 -> "overcast"
        45, 48 -> "foggy"
        in 51..57 -> "drizzling"
        in 61..67, in 80..82 -> "raining"
        in 71..77, 85, 86 -> "snowing"
        in 95..99 -> "stormy"
        else -> "mixed"
    }

    /** First two sentences, so spoken answers stay short. */
    private fun shorten(text: String): String {
        val sentences = Regex("(?<=[.!?])\\s+").split(text.trim())
        return sentences.take(2).joinToString(" ").take(400)
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 10000
        c.setRequestProperty("User-Agent", "JarvisLauncher/0.2 (personal Android launcher)")
        return c.inputStream.bufferedReader().use { it.readText() }
    }
}
