package com.arnave.jarvis.voice

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.SystemClock
import android.provider.Settings
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import com.arnave.jarvis.MainActivity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Watches for the Nothing Phone's Essential Key (or any button you teach it) and wakes Jarvis.
 * Default is a double press, so the Essential Key's normal single press keeps working.
 * Also gives Jarvis system actions: screenshot, lock screen, recents, quick settings.
 */
class EssentialKeyService : AccessibilityService() {

    private var lastUp = 0L

    override fun onServiceConnected() {
        instance = this
        _connected.value = true
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        _connected.value = false
        return super.onUnbind(intent)
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val prefs = prefs(this)

        if (_learning.value) {
            if (event.action == KeyEvent.ACTION_UP) {
                prefs.edit().putInt(KEY_CODE, event.keyCode).putInt(SCAN_CODE, event.scanCode).apply()
                _learning.value = false
                _learnedKey.value = describe(event.keyCode, event.scanCode)
            }
            return true // swallow the key while learning
        }

        val savedCode = prefs.getInt(KEY_CODE, Int.MIN_VALUE)
        val savedScan = prefs.getInt(SCAN_CODE, Int.MIN_VALUE)
        if (savedCode == Int.MIN_VALUE) return false
        // The Essential Key shows up as an unknown keycode (0), so match it by scan code instead.
        val matches = if (savedCode == KeyEvent.KEYCODE_UNKNOWN) event.scanCode == savedScan else event.keyCode == savedCode
        if (!matches) return false

        val singlePress = prefs.getBoolean(SINGLE_PRESS, false)
        if (event.action == KeyEvent.ACTION_UP) {
            val now = SystemClock.uptimeMillis()
            if (singlePress || now - lastUp < 450) {
                lastUp = 0
                wake()
            } else lastUp = now
        }
        // In single-press mode Jarvis owns the key; otherwise the system still gets it.
        return singlePress
    }

    private fun wake() {
        startActivity(
            Intent(this, MainActivity::class.java)
                .setAction(MainActivity.ACTION_WAKE)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        )
    }

    /** Returns a spoken complaint on failure, null on success. */
    fun global(command: String): String? {
        val action = when (command) {
            "screenshot" -> if (Build.VERSION.SDK_INT >= 28) GLOBAL_ACTION_TAKE_SCREENSHOT else return "Screenshots need Android 9 or newer."
            "lock" -> if (Build.VERSION.SDK_INT >= 28) GLOBAL_ACTION_LOCK_SCREEN else return "Locking needs Android 9 or newer."
            "recents" -> GLOBAL_ACTION_RECENTS
            "quick_settings" -> GLOBAL_ACTION_QUICK_SETTINGS
            "notifications" -> GLOBAL_ACTION_NOTIFICATIONS
            else -> return "I don't know that system command."
        }
        return if (performGlobalAction(action)) null else "The system refused that one."
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    companion object {
        @Volatile var instance: EssentialKeyService? = null
            private set

        private val _connected = MutableStateFlow(false)
        val connected = _connected.asStateFlow()
        private val _learning = MutableStateFlow(false)
        val learning = _learning.asStateFlow()
        private val _learnedKey = MutableStateFlow<String?>(null)
        val learnedKey = _learnedKey.asStateFlow()

        private const val KEY_CODE = "wake_key_code"
        private const val SCAN_CODE = "wake_scan_code"
        private const val SINGLE_PRESS = "wake_key_single"

        private fun prefs(c: Context) = c.getSharedPreferences("jarvis_settings", Context.MODE_PRIVATE)

        fun startLearning() { _learning.value = true }
        fun cancelLearning() { _learning.value = false }

        fun savedKey(c: Context): String? {
            val p = prefs(c)
            val code = p.getInt(KEY_CODE, Int.MIN_VALUE)
            return if (code == Int.MIN_VALUE) null else describe(code, p.getInt(SCAN_CODE, 0))
        }

        fun singlePress(c: Context) = prefs(c).getBoolean(SINGLE_PRESS, false)
        fun setSinglePress(c: Context, on: Boolean) = prefs(c).edit().putBoolean(SINGLE_PRESS, on).apply()

        fun isEnabled(c: Context): Boolean {
            val enabled = Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES).orEmpty()
            return enabled.contains("${c.packageName}/") && enabled.contains(EssentialKeyService::class.java.simpleName)
        }

        private fun describe(code: Int, scan: Int) =
            if (code == KeyEvent.KEYCODE_UNKNOWN) "Button #$scan" else KeyEvent.keyCodeToString(code).removePrefix("KEYCODE_")
    }
}
