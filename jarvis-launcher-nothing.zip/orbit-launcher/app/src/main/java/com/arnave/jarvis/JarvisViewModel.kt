package com.arnave.jarvis

import android.app.Application
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.arnave.jarvis.brain.ActionRunner
import com.arnave.jarvis.brain.Assistant
import com.arnave.jarvis.brain.Knowledge
import com.arnave.jarvis.brain.DeviceContext
import com.arnave.jarvis.data.AppEntry
import com.arnave.jarvis.data.AppRepository
import com.arnave.jarvis.data.UsageTracker
import com.arnave.jarvis.notify.NotificationStore
import com.arnave.jarvis.voice.VoiceController
import com.arnave.jarvis.voice.WakeWordService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDateTime

enum class Mode { Idle, Listening, Thinking, Speaking }
enum class Panel { None, Apps, Notifications }
data class Exchange(val you: String, val jarvis: String)

class JarvisViewModel(private val app: Application) : AndroidViewModel(app), ActionRunner.UiHooks {

    private val repo = AppRepository(app)
    private val usage = UsageTracker(app)
    val settings = JarvisSettings(app)

    private val _apps = MutableStateFlow<List<AppEntry>>(emptyList()); val apps = _apps.asStateFlow()
    private val _suggested = MutableStateFlow<List<AppEntry>>(emptyList()); val suggested = _suggested.asStateFlow()
    private val _mode = MutableStateFlow(Mode.Idle); val mode = _mode.asStateFlow()
    private val _heard = MutableStateFlow(""); val heard = _heard.asStateFlow()
    private val _log = MutableStateFlow<List<Exchange>>(emptyList()); val log = _log.asStateFlow()
    private val _level = MutableStateFlow(0f); val level = _level.asStateFlow()
    private val _panel = MutableStateFlow(Panel.None); val panel = _panel.asStateFlow()
    private val _battery = MutableStateFlow(0 to false); val battery = _battery.asStateFlow()

    private val assistant = Assistant(
        name = { settings.name },
        sir = { settings.honorific },
        knowledge = Knowledge(app),
    )

    private val voice = VoiceController(
        app,
        onPartial = { _heard.value = it },
        onFinal = { submit(it) },
        onListenEnd = { heard -> if (!heard && _mode.value == Mode.Listening) goIdle() },
        onLevel = { _level.value = it },
    )

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            i ?: return
            val pct = i.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) * 100 / i.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
            val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            _battery.value = pct to (status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL)
        }
    }

    init {
        app.registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    }

    fun refreshApps() = viewModelScope.launch {
        _apps.value = withContext(Dispatchers.IO) { repo.loadApps() }
        updateSuggestions()
    }

    private fun updateSuggestions() {
        _suggested.value = _apps.value.sortedByDescending { usage.score(it.packageName) }.take(6)
    }

    fun setPanel(p: Panel) { _panel.value = p }

    /** Called on wake word, or when the core is tapped. */
    fun startListening() {
        if (!voice.canListen) { speakAndLog("", "Speech recognition isn't available on this phone, ${settings.honorific}. You can type to me instead."); return }
        WakeWordService.pause(app)
        _panel.value = Panel.None
        _heard.value = ""
        _mode.value = Mode.Listening
        voice.listen()
    }

    fun stopEverything() {
        voice.cancelListening()
        voice.stopSpeaking()
        goIdle()
    }

    fun submit(text: String) {
        val input = text.trim()
        if (input.isEmpty()) return
        _heard.value = input
        _mode.value = Mode.Thinking
        viewModelScope.launch {
            val reply = assistant.handle(input, deviceContext())
            val problems = reply.actions.mapNotNull { ActionRunner.run(app, it, this@JarvisViewModel) }
            val say = listOf(reply.say, *problems.toTypedArray()).filter { it.isNotBlank() }.joinToString(" ")
            speakAndLog(input, say)
        }
    }

    private fun speakAndLog(you: String, say: String) {
        _log.value = (_log.value + Exchange(you, say)).takeLast(8)
        if (settings.voiceReplies && say.isNotBlank()) {
            _mode.value = Mode.Speaking
            voice.speak(say) { goIdle() }
        } else goIdle()
    }

    private fun goIdle() {
        _mode.value = Mode.Idle
        _level.value = 0f
        if (settings.picovoiceKey.isNotBlank()) WakeWordService.resume(app)
    }

    fun forgetConversation() {
        _log.value = emptyList()
    }

    fun greet() {
        val h = LocalDateTime.now().hour
        val part = when (h) { in 5..11 -> "Good morning"; in 12..16 -> "Good afternoon"; else -> "Good evening" }
        _log.value = listOf(Exchange("", "$part, ${settings.honorific}. All systems online."))
    }

    private fun deviceContext(): DeviceContext = DeviceContext(
        battery = _battery.value.first,
        charging = _battery.value.second,
        notificationCount = NotificationStore.items.value.size,
        notificationDigest = NotificationStore.spokenDigest(),
        apps = _apps.value,
    )

    // ActionRunner.UiHooks
    override fun onAppOpened(app: AppEntry) { usage.record(app.packageName); updateSuggestions(); _panel.value = Panel.None }
    override fun showNotifications() { _panel.value = Panel.Notifications }
    override fun showApps() { _panel.value = Panel.Apps }

    fun openApp(entry: AppEntry) {
        ActionRunner.openApp(app, entry)
        onAppOpened(entry)
    }

    override fun onCleared() {
        runCatching { app.unregisterReceiver(batteryReceiver) }
        voice.release()
        super.onCleared()
    }
}

class JarvisSettings(context: Context) {
    private val p = context.getSharedPreferences("jarvis_settings", Context.MODE_PRIVATE)
    var picovoiceKey: String
        get() = p.getString("picovoice_key", "").orEmpty()
        set(v) = p.edit().putString("picovoice_key", v.trim()).apply()
    var name: String
        get() = p.getString("name", "Jarvis").orEmpty().ifBlank { "Jarvis" }
        set(v) = p.edit().putString("name", v.trim()).apply()
    var honorific: String
        get() = p.getString("honorific", "sir").orEmpty().ifBlank { "sir" }
        set(v) = p.edit().putString("honorific", v.trim()).apply()
    var voiceReplies: Boolean
        get() = p.getBoolean("voice_replies", true)
        set(v) = p.edit().putBoolean("voice_replies", v).apply()
}
