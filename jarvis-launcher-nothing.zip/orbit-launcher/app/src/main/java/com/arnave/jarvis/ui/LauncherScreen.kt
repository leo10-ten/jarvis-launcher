package com.arnave.jarvis.ui

import android.content.Intent
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.arnave.jarvis.JarvisViewModel
import com.arnave.jarvis.Mode
import com.arnave.jarvis.Panel
import com.arnave.jarvis.brain.ActionRunner
import com.arnave.jarvis.data.AppEntry
import com.arnave.jarvis.data.AppMatcher
import com.arnave.jarvis.notify.HudNotification
import com.arnave.jarvis.notify.NotificationStore
import com.arnave.jarvis.voice.EssentialKeyService
import com.arnave.jarvis.voice.WakeBus
import com.arnave.jarvis.voice.WakeWordService
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Date
import java.util.Locale

@Composable
fun LauncherScreen(vm: JarvisViewModel) {
    val context = LocalContext.current
    val focus = LocalFocusManager.current
    val apps by vm.apps.collectAsStateWithLifecycle()
    val suggested by vm.suggested.collectAsStateWithLifecycle()
    val mode by vm.mode.collectAsStateWithLifecycle()
    val heard by vm.heard.collectAsStateWithLifecycle()
    val log by vm.log.collectAsStateWithLifecycle()
    val level by vm.level.collectAsStateWithLifecycle()
    val panel by vm.panel.collectAsStateWithLifecycle()
    val battery by vm.battery.collectAsStateWithLifecycle()
    val notifications by NotificationStore.items.collectAsStateWithLifecycle()
    val wake by WakeBus.status.collectAsStateWithLifecycle()
    var showSettings by remember { mutableStateOf(false) }
    var input by rememberSaveable { mutableStateOf("") }

    val appInfo: (AppEntry) -> Unit = { ActionRunner.appInfo(context, it) }

    BackHandler {
        when {
            panel != Panel.None -> vm.setPanel(Panel.None)
            mode != Mode.Idle -> vm.stopEverything()
        }
        focus.clearFocus()
    }

    Box(Modifier.fillMaxSize()) {
        HudBackground()

        Column(
            Modifier
                .fillMaxSize()
                .navigationBarsPadding()
                .imePadding()
                .pointerInput(Unit) {
                    var startY = 0f
                    var total = 0f
                    detectVerticalDragGestures(
                        onDragStart = { startY = it.y; total = 0f },
                        onDragEnd = {
                            if (total < -120f) vm.setPanel(Panel.Apps)
                            else if (total > 120f && startY < size.height * 0.3f) vm.setPanel(Panel.Notifications)
                        },
                    ) { _, dy -> total += dy }
                },
        ) {
            HudStatusBar(
                battery = battery.first, charging = battery.second,
                notifications = notifications.size, wake = wake,
                modifier = Modifier
                    .windowInsetsPadding(WindowInsets.safeDrawing.only(WindowInsetsSides.Top))
                    .clickable { vm.setPanel(Panel.Notifications) },
            )
            HudDivider()
            ClockBlock(Modifier.padding(horizontal = 20.dp, vertical = 12.dp))

            HudCore(
                mode = mode, level = level, title = vm.settings.name,
                modifier = Modifier.size(250.dp).align(Alignment.CenterHorizontally),
                onTap = { if (mode == Mode.Idle) vm.startListening() else vm.stopEverything() },
                onLongPress = { showSettings = true },
            )

            if (mode != Mode.Idle && heard.isNotBlank()) {
                HudText(
                    "“$heard”", size = 13.sp, color = Hud.Cyan, maxLines = 2,
                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 6.dp).align(Alignment.CenterHorizontally),
                )
            }

            if (log.isNotEmpty()) {
                HudFrame(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        log.takeLast(3).forEach { ex ->
                            if (ex.you.isNotBlank()) HudText("> ${ex.you}", size = 11.sp, color = Hud.CyanDim, maxLines = 2)
                            if (ex.jarvis.isNotBlank()) HudText("◆ ${ex.jarvis}", size = 12.sp, color = Hud.Text, maxLines = 4)
                        }
                    }
                }
            }

            Spacer(Modifier.weight(1f))

            if (suggested.isNotEmpty()) {
                HudText("PRIORITY APPS", size = 9.sp, color = Hud.CyanDim, modifier = Modifier.padding(start = 20.dp, bottom = 4.dp))
                LazyRow(contentPadding = PaddingValues(horizontal = 12.dp)) {
                    items(suggested, key = { it.component.flattenToString() }) {
                        HudAppIcon(it, onOpen = vm::openApp, onLongPress = appInfo)
                    }
                }
            }

            CommandBar(
                value = input,
                onChange = { input = it },
                onSend = { vm.submit(input); input = ""; focus.clearFocus() },
                onMic = { focus.clearFocus(); vm.startListening() },
                onApps = { vm.setPanel(Panel.Apps) },
                modifier = Modifier.padding(16.dp),
            )
        }

        AnimatedVisibility(
            visible = panel == Panel.Apps,
            enter = slideInVertically { it } + fadeIn(), exit = slideOutVertically { it } + fadeOut(),
        ) {
            AppsPanel(apps, onOpen = vm::openApp, onLongPress = appInfo, onClose = { vm.setPanel(Panel.None) })
        }
        AnimatedVisibility(
            visible = panel == Panel.Notifications,
            enter = slideInVertically { -it } + fadeIn(), exit = slideOutVertically { -it } + fadeOut(),
        ) {
            NotificationsPanel(
                items = notifications,
                onClose = { vm.setPanel(Panel.None) },
                onSummarise = { vm.setPanel(Panel.None); vm.submit("Read my notifications") },
            )
        }
    }

    if (showSettings) SettingsDialog(vm) { showSettings = false }
}

@Composable
private fun HudDivider() {
    Box(Modifier.fillMaxWidth().height(1.dp).padding(horizontal = 16.dp).background(Hud.Cyan.copy(alpha = 0.2f)))
}

@Composable
private fun ClockBlock(modifier: Modifier = Modifier) {
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    LaunchedEffect(Unit) { while (true) { now = LocalDateTime.now(); delay(1000) } }
    Column(modifier) {
        HudText(now.format(DateTimeFormatter.ofPattern("HH:mm")), size = 46.sp, color = Hud.Text, weight = FontWeight.Light)
        HudText(now.format(DateTimeFormatter.ofPattern("EEEE · d MMMM yyyy")).uppercase(), size = 11.sp, color = Hud.Cyan)
    }
}

@Composable
fun HudButton(label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier
            .border(1.dp, Hud.Cyan.copy(alpha = 0.6f), RoundedCornerShape(3.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center,
    ) { HudText(label, size = 10.sp, color = Hud.Cyan, weight = FontWeight.Bold) }
}

@Composable
private fun CommandBar(
    value: String,
    onChange: (String) -> Unit,
    onSend: () -> Unit,
    onMic: () -> Unit,
    onApps: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier
            .fillMaxWidth()
            .background(Hud.Panel, RoundedCornerShape(4.dp))
            .border(1.dp, Hud.Cyan.copy(alpha = 0.35f), RoundedCornerShape(4.dp))
            .padding(6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Box(Modifier.weight(1f).padding(horizontal = 8.dp, vertical = 10.dp)) {
            if (value.isEmpty()) HudText("ENTER COMMAND…", size = 12.sp, color = Hud.CyanDim)
            BasicTextField(
                value = value, onValueChange = onChange, singleLine = true,
                textStyle = TextStyle(fontFamily = Hud.Mono, fontSize = 13.sp, color = Hud.Text),
                cursorBrush = SolidColor(Hud.Cyan),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { onSend() }),
                modifier = Modifier.fillMaxWidth(),
            )
        }
        if (value.isNotBlank()) HudButton("SEND", onClick = onSend) else HudButton("MIC", onClick = onMic)
        HudButton("APPS", onClick = onApps)
    }
}

@Composable
private fun AppsPanel(apps: List<AppEntry>, onOpen: (AppEntry) -> Unit, onLongPress: (AppEntry) -> Unit, onClose: () -> Unit) {
    var filter by rememberSaveable { mutableStateOf("") }
    val shown = remember(filter, apps) { if (filter.isBlank()) apps else AppMatcher.rank(filter, apps) }
    Column(
        Modifier.fillMaxSize().background(Hud.Bg.copy(alpha = 0.97f))
            .windowInsetsPadding(WindowInsets.safeDrawing),
    ) {
        PanelHeader("APPLICATIONS · ${apps.size}", onClose)
        Box(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp)
                .border(1.dp, Hud.Cyan.copy(alpha = 0.35f), RoundedCornerShape(4.dp))
                .padding(12.dp),
        ) {
            if (filter.isEmpty()) HudText("FILTER…", size = 12.sp, color = Hud.CyanDim)
            BasicTextField(
                value = filter, onValueChange = { filter = it }, singleLine = true,
                textStyle = TextStyle(fontFamily = Hud.Mono, fontSize = 13.sp, color = Hud.Text),
                cursorBrush = SolidColor(Hud.Cyan),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(onGo = { shown.firstOrNull()?.let(onOpen) }),
                modifier = Modifier.fillMaxWidth(),
            )
        }
        LazyVerticalGrid(
            columns = GridCells.Adaptive(80.dp),
            contentPadding = PaddingValues(12.dp),
            modifier = Modifier.fillMaxSize(),
        ) {
            items(shown, key = { it.component.flattenToString() }) { HudAppIcon(it, onOpen, onLongPress) }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun NotificationsPanel(items: List<HudNotification>, onClose: () -> Unit, onSummarise: () -> Unit) {
    val context = LocalContext.current
    val granted = NotificationStore.isAccessGranted(context)
    val fmt = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
    Column(
        Modifier.fillMaxSize().background(Hud.Bg.copy(alpha = 0.97f))
            .windowInsetsPadding(WindowInsets.safeDrawing),
    ) {
        PanelHeader("COMMS · ${items.size}", onClose)
        if (!granted) {
            HudFrame(Modifier.fillMaxWidth().padding(16.dp)) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    HudText("Notification access is off. Grant it so I can show and read your notifications here.", size = 12.sp)
                    HudButton("GRANT ACCESS") {
                        context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    }
                }
            }
            return@Column
        }
        Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            HudButton("READ ALOUD", onClick = onSummarise)
            HudButton("CLEAR ALL") { NotificationStore.dismissAll() }
        }
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(items, key = { it.key }) { n ->
                HudFrame(
                    Modifier.fillMaxWidth().combinedClickable(
                        onClick = {
                            runCatching { n.contentIntent?.send() }
                            NotificationStore.dismiss(n.key)
                            onClose()
                        },
                        onLongClick = { NotificationStore.dismiss(n.key) },
                    )
                ) {
                    Column {
                        Row {
                            HudText(n.app.uppercase(), size = 9.sp, color = Hud.Cyan, modifier = Modifier.weight(1f))
                            HudText(fmt.format(Date(n.time)), size = 9.sp, color = Hud.CyanDim)
                        }
                        Spacer(Modifier.height(4.dp))
                        if (n.title.isNotBlank()) HudText(n.title, size = 13.sp, weight = FontWeight.Bold, maxLines = 1)
                        if (n.text.isNotBlank()) HudText(n.text, size = 12.sp, color = Hud.Text.copy(alpha = 0.8f), maxLines = 3)
                    }
                }
            }
        }
    }
}

@Composable
private fun PanelHeader(title: String, onClose: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
        HudText(title, size = 14.sp, color = Hud.Cyan, weight = FontWeight.Bold, modifier = Modifier.weight(1f))
        HudButton("CLOSE", onClick = onClose)
    }
}

@Composable
private fun SettingsDialog(vm: JarvisViewModel, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val s = vm.settings
    var name by remember { mutableStateOf(s.name) }
    var honorific by remember { mutableStateOf(s.honorific) }
    var pico by remember { mutableStateOf(s.picovoiceKey) }
    var voice by remember { mutableStateOf(s.voiceReplies) }
    var single by remember { mutableStateOf(EssentialKeyService.singlePress(context)) }
    val keyConnected by EssentialKeyService.connected.collectAsStateWithLifecycle()
    val learning by EssentialKeyService.learning.collectAsStateWithLifecycle()
    val learned by EssentialKeyService.learnedKey.collectAsStateWithLifecycle()
    val savedKey = learned ?: EssentialKeyService.savedKey(context)

    AlertDialog(
        onDismissRequest = { EssentialKeyService.cancelLearning(); onDismiss() },
        containerColor = Hud.Panel,
        title = { HudText("SYSTEM CONFIG", size = 14.sp, color = Hud.Cyan, weight = FontWeight.Bold) },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                OutlinedTextField(name, { name = it }, label = { Text("Assistant name") }, singleLine = true)
                OutlinedTextField(honorific, { honorific = it }, label = { Text("Call me") }, singleLine = true)

                HudText("ESSENTIAL KEY", size = 11.sp, color = Hud.Cyan, weight = FontWeight.Bold)
                when {
                    !keyConnected -> {
                        HudText("Step 1: switch on \"Jarvis (Essential Key)\" in Accessibility.", size = 10.sp)
                        HudButton("OPEN ACCESSIBILITY") {
                            context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        }
                    }
                    learning -> HudText("Press the Essential Key now…", size = 11.sp, color = Hud.Amber)
                    else -> {
                        HudText(if (savedKey == null) "Step 2: teach me the key." else "Wake key: $savedKey", size = 10.sp)
                        HudButton(if (savedKey == null) "LEARN KEY" else "RE-LEARN KEY") { EssentialKeyService.startLearning() }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            HudText(if (single) "SINGLE PRESS WAKES" else "DOUBLE PRESS WAKES", size = 10.sp, modifier = Modifier.weight(1f))
                            Switch(single, { single = it; EssentialKeyService.setSinglePress(context, it) })
                        }
                    }
                }

                HudText("VOICE WAKE (\"JARVIS\")", size = 11.sp, color = Hud.Cyan, weight = FontWeight.Bold)
                HudText("Optional. Free key from console.picovoice.ai, no payment needed.", size = 10.sp)
                OutlinedTextField(
                    pico, { pico = it }, label = { Text("Picovoice AccessKey") },
                    singleLine = true, visualTransformation = PasswordVisualTransformation(),
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    HudText("SPOKEN REPLIES", size = 11.sp, modifier = Modifier.weight(1f))
                    Switch(voice, { voice = it })
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    HudButton("CLEAR LOG") { vm.forgetConversation() }
                    HudButton("DEFAULT HOME") {
                        context.startActivity(Intent(Settings.ACTION_HOME_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                s.name = name; s.honorific = honorific; s.picovoiceKey = pico; s.voiceReplies = voice
                if (pico.isNotBlank()) {
                    WakeWordService.stop(context) // rebuild with the new key
                    WakeWordService.ensureStarted(context)
                } else WakeWordService.stop(context)
                EssentialKeyService.cancelLearning()
                onDismiss()
            }) { Text("SAVE") }
        },
        dismissButton = { TextButton(onClick = { EssentialKeyService.cancelLearning(); onDismiss() }) { Text("CANCEL") } },
    )
}
