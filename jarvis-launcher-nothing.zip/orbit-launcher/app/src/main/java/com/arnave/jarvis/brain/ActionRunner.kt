package com.arnave.jarvis.brain

import android.Manifest
import android.app.SearchManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.view.KeyEvent
import androidx.core.content.ContextCompat
import com.arnave.jarvis.data.AppEntry
import com.arnave.jarvis.notify.NotificationStore
import com.arnave.jarvis.voice.EssentialKeyService

/** Turns assistant actions into real Android intents and system calls. */
object ActionRunner {

    /** Runs one action. Returns a spoken complaint if it couldn't be done, or null on success. */
    fun run(context: Context, action: Action, ui: UiHooks): String? = when (action) {
        is Action.OpenApp -> { openApp(context, action.app); ui.onAppOpened(action.app); null }
        is Action.WebSearch -> start(
            context,
            Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, action.query),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(action.query))),
        )
        is Action.YouTube -> start(
            context,
            Intent(Intent.ACTION_SEARCH).setPackage("com.google.android.youtube").putExtra("query", action.query),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(action.query))),
        )
        is Action.AskGemini -> askGemini(context, action.query)
        Action.Camera -> start(context, Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
        Action.Selfie -> start(
            context,
            Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
                .putExtra("android.intent.extras.CAMERA_FACING", 1)
                .putExtra("android.intent.extras.LENS_FACING_FRONT", 1)
                .putExtra("android.intent.extra.USE_FRONT_CAMERA", true),
        )
        is Action.System -> EssentialKeyService.instance?.global(action.command)
            ?: "Switch on Jarvis in Accessibility settings and I can do that, too."
        is Action.Call -> {
            val number = resolveNumber(context, action.who)
            if (number == null) "I couldn't find ${action.who} in your contacts."
            else {
                val canCall = ContextCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE) ==
                    PackageManager.PERMISSION_GRANTED
                start(context, Intent(if (canCall) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number))))
            }
        }
        is Action.Message -> {
            val number = resolveNumber(context, action.who)
            if (number == null) "I couldn't find ${action.who} in your contacts."
            else start(context, Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(number))).putExtra("sms_body", action.body))
        }
        is Action.Timer -> start(
            context,
            Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, action.seconds)
                .putExtra(AlarmClock.EXTRA_MESSAGE, action.label.ifBlank { "Jarvis timer" })
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true),
        )
        is Action.Alarm -> start(
            context,
            Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, action.hour)
                .putExtra(AlarmClock.EXTRA_MINUTES, action.minute)
                .putExtra(AlarmClock.EXTRA_MESSAGE, action.label.ifBlank { "Jarvis alarm" })
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true),
        )
        is Action.Navigate -> start(
            context,
            Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(action.place))),
            Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(action.place))),
        )
        is Action.Settings -> start(context, Intent(settingsAction(action.page)))
        is Action.Torch -> torch(context, action.on)
        is Action.Media -> { media(context, action.command); null }
        is Action.Volume -> { volume(context, action.command); null }
        Action.ShowNotifications -> { ui.showNotifications(); null }
        Action.ClearNotifications -> { NotificationStore.dismissAll(); null }
        Action.ShowApps -> { ui.showApps(); null }
    }

    interface UiHooks {
        fun onAppOpened(app: AppEntry)
        fun showNotifications()
        fun showApps()
    }

    fun openApp(context: Context, app: AppEntry) {
        start(context, Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(app.component)
            .addFlags(Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED))
    }

    /** Open-ended questions go to the phone's built-in AI: Gemini first, then Google search. */
    private fun askGemini(context: Context, query: String): String? {
        if (query.isBlank()) return start(context, Intent(Intent.ACTION_VOICE_COMMAND), Intent(Intent.ACTION_ASSIST))
        return start(
            context,
            Intent(Intent.ACTION_SEND).setType("text/plain").setPackage(GEMINI).putExtra(Intent.EXTRA_TEXT, query),
            Intent(Intent.ACTION_WEB_SEARCH).setPackage(GOOGLE).putExtra(SearchManager.QUERY, query),
            Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, query),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(query))),
        )
    }

    private const val GEMINI = "com.google.android.apps.bard"
    private const val GOOGLE = "com.google.android.googlequicksearchbox"

    fun appInfo(context: Context, app: AppEntry) {
        start(context, Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.packageName}")))
    }

    private fun start(context: Context, vararg intents: Intent): String? {
        for (intent in intents) {
            try {
                context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                return null
            } catch (_: ActivityNotFoundException) {
            } catch (_: SecurityException) {
            }
        }
        return "This phone doesn't have an app that can do that."
    }

    private fun settingsAction(page: String) = when (page.lowercase()) {
        "wifi" -> Settings.ACTION_WIFI_SETTINGS
        "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
        "battery" -> Intent.ACTION_POWER_USAGE_SUMMARY
        "display" -> Settings.ACTION_DISPLAY_SETTINGS
        "sound" -> Settings.ACTION_SOUND_SETTINGS
        "location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
        "apps" -> Settings.ACTION_APPLICATION_SETTINGS
        else -> Settings.ACTION_SETTINGS
    }

    private fun resolveNumber(context: Context, who: String): String? {
        val digits = who.filter { it.isDigit() || it == '+' }
        if (digits.length >= 3 && digits.length >= who.count { !it.isWhitespace() } - 2) return digits
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        val uri = Uri.withAppendedPath(ContactsContract.CommonDataKinds.Phone.CONTENT_FILTER_URI, Uri.encode(who))
        context.contentResolver.query(uri, arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER), null, null, null)?.use { c ->
            if (c.moveToFirst()) return c.getString(0)
        }
        return null
    }

    private fun torch(context: Context, on: Boolean): String? = runCatching {
        val cm = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.first { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
        cm.setTorchMode(id, on)
        null
    }.getOrElse { "I can't reach the torch on this phone." }

    private fun media(context: Context, command: String) {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val code = when (command) {
            "pause" -> KeyEvent.KEYCODE_MEDIA_PAUSE
            "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
            "previous" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            else -> KeyEvent.KEYCODE_MEDIA_PLAY
        }
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun volume(context: Context, command: String) {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val s = AudioManager.STREAM_MUSIC
        when (command) {
            "up" -> am.adjustStreamVolume(s, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
            "down" -> am.adjustStreamVolume(s, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            "mute" -> am.adjustStreamVolume(s, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
            "max" -> am.setStreamVolume(s, am.getStreamMaxVolume(s), AudioManager.FLAG_SHOW_UI)
        }
    }
}
