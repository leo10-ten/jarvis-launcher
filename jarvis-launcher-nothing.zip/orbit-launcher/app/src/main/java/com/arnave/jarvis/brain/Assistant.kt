package com.arnave.jarvis.brain

import com.arnave.jarvis.data.AppEntry
import com.arnave.jarvis.data.AppMatcher
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

/** Everything the assistant can do on the phone. */
sealed interface Action {
    data class OpenApp(val app: AppEntry) : Action
    data class WebSearch(val query: String) : Action
    data class YouTube(val query: String) : Action
    data class AskGemini(val query: String) : Action
    data class Call(val who: String) : Action          // number or contact name
    data class Message(val who: String, val body: String) : Action
    data class Timer(val seconds: Int, val label: String) : Action
    data class Alarm(val hour: Int, val minute: Int, val label: String) : Action
    data class Navigate(val place: String) : Action
    data class Settings(val page: String) : Action
    data class Torch(val on: Boolean) : Action
    data class Media(val command: String) : Action      // play, pause, next, previous
    data class Volume(val command: String) : Action     // up, down, mute, max
    data class System(val command: String) : Action     // screenshot, lock, recents, quick_settings
    data object Camera : Action
    data object Selfie : Action
    data object ShowNotifications : Action
    data object ClearNotifications : Action
    data object ShowApps : Action
}

data class Reply(val say: String, val actions: List<Action> = emptyList())

/** Snapshot of the phone the assistant works from. Stays on the device. */
data class DeviceContext(
    val battery: Int,
    val charging: Boolean,
    val notificationCount: Int,
    val notificationDigest: String,
    val apps: List<AppEntry>,
)

/**
 * Key-free brain: an on-device command engine for everything on the phone, free public
 * lookups (DuckDuckGo, Wikipedia, Open-Meteo) for questions and weather, and a hand-off
 * to the phone's built-in Gemini / Google search for anything else.
 */
class Assistant(
    private val name: () -> String,
    private val sir: () -> String,
    private val knowledge: Knowledge,
) {
    suspend fun handle(input: String, ctx: DeviceContext): Reply {
        val text = cleanup(input, name())
        CommandEngine.parse(text, ctx, sir(), name())?.let { return it }

        val lower = text.lowercase()
        if (CommandEngine.isWeather(lower)) {
            return knowledge.weather()?.let { Reply("$it, ${sir()}.") }
                ?: Reply("I couldn't get the weather — check location and internet, ${sir()}.", listOf(Action.WebSearch("weather")))
        }
        val topic = CommandEngine.questionTopic(lower)
        if (topic != null) {
            knowledge.lookup(topic)?.let { return Reply(it) }
        }
        // Anything open-ended goes to the phone's own AI.
        return Reply("Let me look into that for you, ${sir()}.", listOf(Action.AskGemini(text)))
    }

    private fun cleanup(input: String, name: String) = input.trim()
        .replace(Regex("^(hey |ok |okay )?${Regex.escape(name)}[,.!]?\\s*", RegexOption.IGNORE_CASE), "")
        .replace(Regex("^(please |can you |could you |would you )", RegexOption.IGNORE_CASE), "")
        .trim().trimEnd('?', '.', '!')
}

/** All on-device understanding. Returns null when the request needs outside knowledge. */
object CommandEngine {
    private val open = Regex("^(?:open|launch|start|run|go to)\\s+(?:the\\s+)?(.+?)(?:\\s+app)?$")
    private val timer = Regex("(?:timer (?:for )?(\\d+)\\s*(seconds?|secs?|minutes?|mins?|hours?|hrs?)\\b)|(?:(\\d+)\\s*(seconds?|secs?|minutes?|mins?|hours?|hrs?)\\s+timer)")
    private val alarm = Regex("(?:alarm|wake me(?: up)?)\\s*(?:for|at)?\\s*(\\d{1,2})(?:[:.](\\d{2}))?\\s*(am|pm|a\\.m\\.|p\\.m\\.)?")
    private val message = Regex("^(?:text|message|whatsapp|sms|send (?:a )?(?:message|text) to)\\s+(.+?)\\s+(?:saying|that|and say)\\s+(.+)$")
    private val call = Regex("^(?:call|dial|phone|ring)\\s+(.+)$")
    private val navigate = Regex("^(?:navigate|directions|take me|drive|route) to\\s+(.+)$")
    private val search = Regex("^(?:search|google|look up)\\s+(?:for\\s+)?(.+)$")
    private val play = Regex("^(?:play|youtube)\\s+(.+?)(?:\\s+on youtube)?$")
    private val gemini = Regex("^(?:ask gemini|gemini)\\s*(.*)$")
    private val math = Regex("^(?:what(?:'s| is)|calculate|compute|how much is)?\\s*([-\\d.\\s()+*/^x%]+|.*\\b(?:plus|minus|times|multiplied by|divided by|over|into|squared|percent of)\\b.*)$")

    fun parse(lower0: String, ctx: DeviceContext, sir: String, name: String): Reply? {
        val lower = lower0.lowercase()
        fun r(say: String, vararg a: Action) = Reply(say, a.toList())

        // --- Small talk ---------------------------------------------------------------
        when {
            lower.isBlank() -> return r("Yes, $sir?")
            Regex("^(hi|hello|hey|yo|good (morning|afternoon|evening))\\b").containsMatchIn(lower) ->
                return r("${greeting()}, $sir. How can I help?")
            Regex("how are you|how('re| are) you doing").containsMatchIn(lower) ->
                return r("All systems nominal, $sir. Battery at ${ctx.battery} percent. And you?")
            Regex("^(thanks|thank you|cheers)").containsMatchIn(lower) -> return r("Always a pleasure, $sir.")
            Regex("who are you|what('s| is) your name|what are you").containsMatchIn(lower) ->
                return r("I'm $name, your on-device assistant. I run the phone; for big questions I consult the web or Gemini.")
            Regex("what can you do|help me|^help$").containsMatchIn(lower) ->
                return r("I can open apps, call and message people, set timers and alarms, control music, volume and the torch, " +
                    "take screenshots, read your notifications, check the weather and answer questions. Just ask.")
            Regex("tell me a joke|make me laugh").containsMatchIn(lower) -> return r(JOKES.random())
            Regex("^(stop|cancel|never ?mind|nothing)$").containsMatchIn(lower) -> return r("Standing by.")
        }

        // --- Time, date, battery ----------------------------------------------------
        val now = LocalDateTime.now()
        when {
            Regex("what('s| is) the time|time is it|^time$").containsMatchIn(lower) ->
                return r("It's ${now.format(DateTimeFormatter.ofPattern("h:mm a"))}, $sir.")
            Regex("what('s| is) (the |today's )?date|what day is (it|today)|^date$").containsMatchIn(lower) ->
                return r("Today is ${now.format(DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy"))}.")
            lower.contains("battery") && !lower.contains("setting") ->
                return r("Battery is at ${ctx.battery} percent${if (ctx.charging) " and charging" else ""}, $sir.")
        }

        // --- Notifications ----------------------------------------------------------
        when {
            lower.contains("clear") && lower.contains("notification") -> return r("Notifications cleared.", Action.ClearNotifications)
            Regex("(read|any|check|what are) (my |the )?(new )?(notifications|messages)").containsMatchIn(lower) ->
                return if (ctx.notificationCount == 0) r("No new notifications, $sir.")
                else r("You have ${ctx.notificationCount}. ${ctx.notificationDigest}", Action.ShowNotifications)
            lower.contains("notification") -> return r("You have ${ctx.notificationCount} notifications.", Action.ShowNotifications)
        }

        // --- Phone actions ----------------------------------------------------------
        gemini.find(lower)?.let { return r("Opening Gemini.", Action.AskGemini(it.groupValues[1])) }
        timer.find(lower)?.let { m ->
            val n = (m.groups[1] ?: m.groups[3])!!.value.toInt()
            val unit = (m.groups[2] ?: m.groups[4])!!.value
            val secs = n * when { unit.startsWith("s") -> 1; unit.startsWith("m") -> 60; else -> 3600 }
            return r("Timer set for $n $unit, $sir.", Action.Timer(secs, ""))
        }
        alarm.find(lower)?.let { m ->
            var h = m.groupValues[1].toInt()
            val min = m.groupValues[2].toIntOrNull() ?: 0
            val ap = m.groupValues[3]
            if (ap.startsWith("p") && h < 12) h += 12
            if (ap.startsWith("a") && h == 12) h = 0
            if (h in 0..23 && min in 0..59) {
                return r("Alarm set for ${"%d:%02d".format(if (h % 12 == 0) 12 else h % 12, min)} ${if (h < 12) "AM" else "PM"}.", Action.Alarm(h, min, ""))
            }
        }
        message.find(lower)?.let { return r("Drafting a message to ${it.groupValues[1]}.", Action.Message(it.groupValues[1], lower0.takeLast(it.groupValues[2].length))) }
        call.find(lower)?.let { return r("Calling ${it.groupValues[1]}.", Action.Call(it.groupValues[1])) }
        navigate.find(lower)?.let { return r("Plotting a route to ${it.groupValues[1]}.", Action.Navigate(it.groupValues[1])) }
        search.find(lower)?.let { return r("Searching.", Action.WebSearch(it.groupValues[1])) }
        play.find(lower)?.let {
            if (it.groupValues[1] !in setOf("music", "song", "")) return r("Finding it on YouTube.", Action.YouTube(it.groupValues[1]))
        }

        when {
            Regex("selfie").containsMatchIn(lower) -> return r("Front camera ready.", Action.Selfie)
            Regex("take a (photo|picture)|open (the )?camera|^camera$").containsMatchIn(lower) -> return r("Camera ready.", Action.Camera)
            Regex("screenshot|screen ?shot|capture (the )?screen").containsMatchIn(lower) -> return r("Capturing.", Action.System("screenshot"))
            Regex("lock (the )?(phone|screen)").containsMatchIn(lower) -> return r("Locking up, $sir.", Action.System("lock"))
            Regex("recent apps|recents").containsMatchIn(lower) -> return r("Recent apps.", Action.System("recents"))
            Regex("quick settings").containsMatchIn(lower) -> return r("Quick settings.", Action.System("quick_settings"))
            Regex("(torch|flashlight|flash light)").containsMatchIn(lower) ->
                return if (Regex("\\boff\\b|disable").containsMatchIn(lower)) r("Torch off.", Action.Torch(false)) else r("Torch on.", Action.Torch(true))
            Regex("^(pause|stop)( the)?( music| song| playback)?$").containsMatchIn(lower) -> return r("Paused.", Action.Media("pause"))
            Regex("^(resume|play)( the)?( music| song)?$").containsMatchIn(lower) -> return r("Playing.", Action.Media("play"))
            Regex("^(next|skip)( song| track)?$").containsMatchIn(lower) -> return r("Next track.", Action.Media("next"))
            Regex("^(previous|last|go back)( song| track)$").containsMatchIn(lower) -> return r("Previous track.", Action.Media("previous"))
            Regex("volume up|louder|turn it up").containsMatchIn(lower) -> return r("Volume up.", Action.Volume("up"))
            Regex("volume down|quieter|turn it down").containsMatchIn(lower) -> return r("Volume down.", Action.Volume("down"))
            Regex("max(imum)? volume|volume max").containsMatchIn(lower) -> return r("Maximum volume.", Action.Volume("max"))
            Regex("^mute|silence").containsMatchIn(lower) -> return r("Muted.", Action.Volume("mute"))
            Regex("(all )?apps( drawer)?$|show (me )?(my )?apps").containsMatchIn(lower) && lower.length < 20 -> return r("Here are your apps.", Action.ShowApps)
            Regex("\\b(wi-?fi|bluetooth|display|brightness|sound|location|settings)\\b").containsMatchIn(lower) &&
                (lower.startsWith("open") || lower.contains("setting") || lower.split(" ").size <= 2) -> {
                val page = Regex("wi-?fi|bluetooth|display|brightness|sound|location").find(lower)?.value?.replace("-", "")
                    ?.replace("brightness", "display") ?: "main"
                return r("Opening ${if (page == "main") "" else "$page "}settings.", Action.Settings(page))
            }
        }

        open.find(lower)?.let { m ->
            AppMatcher.best(m.groupValues[1], ctx.apps)?.let { return r("Opening ${it.label}.", Action.OpenApp(it)) }
            return r("I don't see ${m.groupValues[1]} installed, $sir.")
        }

        // --- Maths ------------------------------------------------------------------
        if (Regex("\\d").containsMatchIn(lower)) {
            math.find(lower)?.let { m -> Calculator.eval(m.groupValues[1])?.let { return r("That's ${Calculator.format(it)}.") } }
        }

        // --- Bare app name ("whatsapp", "spotify") -------------------------------------
        AppMatcher.rank(lower, ctx.apps).firstOrNull()?.let {
            if (AppMatcher.score(lower, it.label) >= 60) return r("Opening ${it.label}.", Action.OpenApp(it))
        }
        return null
    }

    fun isWeather(lower: String) = Regex("weather|temperature outside|is it (going to )?rain|forecast|how hot|how cold").containsMatchIn(lower)

    /** "who is Ada Lovelace" → "Ada Lovelace". Null if it doesn't look like a factual question. */
    fun questionTopic(lower: String): String? {
        val m = Regex("^(?:who (?:is|was|are|were)|what (?:is|are|was|were)(?: an?| the)?|tell me about|define|meaning of|what does (.+) mean|where is|when (?:is|was))\\s+(.+)$").find(lower)
            ?: return null
        return (m.groupValues[2].ifBlank { m.groupValues[1] }).trim().removePrefix("the ").removePrefix("a ").ifBlank { null }
    }

    private fun greeting() = when (LocalDateTime.now().hour) { in 5..11 -> "Good morning"; in 12..16 -> "Good afternoon"; else -> "Good evening" }

    private val JOKES = listOf(
        "I'd tell you a UDP joke, but you might not get it.",
        "There are 10 kinds of people: those who understand binary and those who don't.",
        "I tried to catch fog yesterday. Mist.",
        "My battery and I have something in common: we both need more charging than we'd like to admit.",
        "Why do programmers prefer dark mode? Because light attracts bugs.",
    )
}

/** Small arithmetic evaluator for spoken maths: "12 times 7", "15 percent of 2400", "(3+4)^2". */
object Calculator {
    fun eval(spoken: String): Double? = runCatching {
        var s = spoken.lowercase()
            .replace(Regex("(\\d+(?:\\.\\d+)?) percent of (\\d+(?:\\.\\d+)?)")) { "(${it.groupValues[1]}/100*${it.groupValues[2]})" }
            .replace("multiplied by", "*").replace("times", "*").replace("into", "*").replace(" x ", "*")
            .replace("divided by", "/").replace("over", "/")
            .replace("plus", "+").replace("minus", "-").replace("squared", "^2").replace("cubed", "^3")
            .replace(Regex("[^0-9+\\-*/^().%]"), "")
        if (s.isBlank() || !Regex("[+\\-*/^]").containsMatchIn(s)) return null
        s = s.replace("%", "/100")
        Parser(s).parseAll()
    }.getOrNull()

    fun format(d: Double): String =
        if (d == Math.floor(d) && kotlin.math.abs(d) < 1e15) d.toLong().toString()
        else "%.4f".format(d).trimEnd('0').trimEnd('.')

    private class Parser(val s: String) {
        var i = 0
        fun parseAll(): Double { val v = expr(); require(i == s.length); return v }
        fun expr(): Double { var v = term(); while (i < s.length && s[i] in "+-") { val op = s[i++]; val t = term(); v = if (op == '+') v + t else v - t }; return v }
        fun term(): Double { var v = power(); while (i < s.length && s[i] in "*/") { val op = s[i++]; val p = power(); v = if (op == '*') v * p else v / p }; return v }
        fun power(): Double { val b = unary(); return if (i < s.length && s[i] == '^') { i++; Math.pow(b, power()) } else b }
        fun unary(): Double = if (i < s.length && s[i] == '-') { i++; -unary() } else atom()
        fun atom(): Double {
            if (s[i] == '(') { i++; val v = expr(); require(s[i++] == ')'); return v }
            val start = i
            while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
            return s.substring(start, i).toDouble()
        }
    }
}
