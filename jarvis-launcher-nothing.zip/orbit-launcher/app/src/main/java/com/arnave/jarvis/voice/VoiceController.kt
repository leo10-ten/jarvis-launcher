package com.arnave.jarvis.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** Speech in (recogniser) and speech out (text-to-speech) for the HUD. Main thread only. */
class VoiceController(
    context: Context,
    private val onPartial: (String) -> Unit,
    private val onFinal: (String) -> Unit,
    private val onListenEnd: (heard: Boolean) -> Unit,
    private val onLevel: (Float) -> Unit,
) {
    private val main = Handler(Looper.getMainLooper())
    private val appContext = context.applicationContext
    private var ttsReady = false
    private val pending = mutableMapOf<String, () -> Unit>()

    private val tts: TextToSpeech = TextToSpeech(appContext) { status ->
        if (status == TextToSpeech.SUCCESS) {
            ttsReady = true
            configureVoice()
        }
    }

    private val recognizer: SpeechRecognizer? =
        if (SpeechRecognizer.isRecognitionAvailable(appContext)) SpeechRecognizer.createSpeechRecognizer(appContext) else null

    val canListen get() = recognizer != null

    init {
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { id?.let { main.post { pending.remove(it)?.invoke() } } }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) { onDone(id) }
        })

        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) = onLevel(((rmsdB + 2f) / 12f).coerceIn(0f, 1f))
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}

            override fun onPartialResults(partialResults: Bundle?) {
                partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let(onPartial)
            }

            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                onLevel(0f)
                if (text.isNotBlank()) onFinal(text)
                onListenEnd(text.isNotBlank())
            }

            override fun onError(error: Int) {
                onLevel(0f)
                onListenEnd(false)
            }
        })
    }

    /** Picks a British English voice when the phone has one — closest to the classic AI-butler sound. */
    private fun configureVoice() {
        tts.language = Locale.UK
        tts.setSpeechRate(1.02f)
        tts.setPitch(0.92f)
        val british = tts.voices.orEmpty().filter { it.locale.language == "en" && it.locale.country == "GB" && !it.isNetworkConnectionRequired }
        val preferred = listOf("rjs", "gbd", "gbb")
        (preferred.firstNotNullOfOrNull { tag -> british.firstOrNull { it.name.contains(tag) } } ?: british.firstOrNull())
            ?.let { tts.voice = it }
    }

    fun speak(text: String, then: () -> Unit = {}) {
        if (!ttsReady || text.isBlank()) { then(); return }
        val id = System.nanoTime().toString()
        pending[id] = then
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, id)
    }

    fun stopSpeaking() {
        tts.stop()
        pending.clear()
    }

    fun listen() {
        val r = recognizer ?: run { onListenEnd(false); return }
        stopSpeaking()
        r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            // Uses the phone's own on-device speech model when it has one: free and works offline.
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        })
    }

    fun cancelListening() = recognizer?.cancel()

    fun release() {
        recognizer?.destroy()
        tts.shutdown()
    }
}
