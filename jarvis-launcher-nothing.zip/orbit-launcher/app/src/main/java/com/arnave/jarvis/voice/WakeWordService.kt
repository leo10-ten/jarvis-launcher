package com.arnave.jarvis.voice

import ai.picovoice.porcupine.Porcupine
import ai.picovoice.porcupine.PorcupineException
import ai.picovoice.porcupine.PorcupineManager
import ai.picovoice.porcupine.PorcupineManagerCallback
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.util.Log
import com.arnave.jarvis.MainActivity
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow

/** Events from the always-on wake word listener to the HUD. */
object WakeBus {
    private val _wakes = MutableSharedFlow<Unit>(extraBufferCapacity = 1)
    val wakes = _wakes.asSharedFlow()
    internal fun fire() = _wakes.tryEmit(Unit)

    private val _status = MutableStateFlow("offline")
    val status = _status.asStateFlow()
    internal fun status(s: String) { _status.value = s }
}

/**
 * Foreground service that listens for "Jarvis" fully on-device (Picovoice Porcupine).
 * Pauses itself while the HUD runs speech recognition, because only one can hold the mic.
 */
class WakeWordService : Service() {

    private var manager: PorcupineManager? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Wake word", NotificationManager.IMPORTANCE_MIN).apply {
                description = "Shown while Jarvis is listening for its name"
            }
        )
        val tap = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Jarvis is standing by")
            .setContentText("Say \"Jarvis\" to talk")
            .setContentIntent(tap)
            .setOngoing(true)
            .build()
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            } else {
                startForeground(ID, n)
            }
        } catch (e: Exception) {
            // Android 14 refuses a microphone service started from the background; the HUD restarts it.
            Log.w(TAG, "Could not enter foreground", e)
            WakeBus.status("offline")
            stopSelf()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_PAUSE -> pause()
            else -> resume()
        }
        return START_STICKY
    }

    private fun resume() {
        val key = getSharedPreferences("jarvis_settings", Context.MODE_PRIVATE).getString("picovoice_key", "").orEmpty()
        if (key.isBlank()) {
            WakeBus.status("no key")
            return
        }
        try {
            if (manager == null) {
                manager = PorcupineManager.Builder()
                    .setAccessKey(key)
                    .setKeyword(Porcupine.BuiltInKeyword.JARVIS)
                    .setSensitivity(0.6f)
                    .build(applicationContext, PorcupineManagerCallback { onWake() })
            }
            manager?.start()
            WakeBus.status("standby")
        } catch (e: PorcupineException) {
            Log.e(TAG, "Porcupine failed", e)
            manager = null
            WakeBus.status("error")
        }
    }

    private fun pause() {
        runCatching { manager?.stop() }
        WakeBus.status("paused")
    }

    private fun onWake() {
        pause()
        WakeBus.fire()
        // As the default home app we're allowed to come to the front from the background.
        startActivity(
            Intent(this, MainActivity::class.java)
                .setAction(MainActivity.ACTION_WAKE)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        )
    }

    override fun onDestroy() {
        runCatching { manager?.stop(); manager?.delete() }
        manager = null
        WakeBus.status("offline")
        super.onDestroy()
    }

    companion object {
        private const val TAG = "WakeWord"
        private const val CHANNEL = "wake"
        private const val ID = 7
        const val ACTION_PAUSE = "jarvis.PAUSE"
        const val ACTION_RESUME = "jarvis.RESUME"

        /** First start — only from the visible HUD, since Android limits starting mic services from the background. */
        fun ensureStarted(context: Context) =
            runCatching { context.startForegroundService(Intent(context, WakeWordService::class.java).setAction(ACTION_RESUME)) }

        /** Resume after the HUD finishes listening. Works from the background because the service is already in the foreground. */
        fun resume(context: Context) =
            runCatching { context.startService(Intent(context, WakeWordService::class.java).setAction(ACTION_RESUME)) }

        fun pause(context: Context) =
            runCatching { context.startService(Intent(context, WakeWordService::class.java).setAction(ACTION_PAUSE)) }

        fun stop(context: Context) = context.stopService(Intent(context, WakeWordService::class.java))
    }
}
