package com.arnave.jarvis

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.arnave.jarvis.ui.HudTheme
import com.arnave.jarvis.ui.LauncherScreen
import com.arnave.jarvis.voice.WakeWordService

class MainActivity : ComponentActivity() {

    private val vm: JarvisViewModel by viewModels()

    private val permissionRequest =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { startWakeWord() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        hideSystemStatusBar()
        setContent { HudTheme { LauncherScreen(vm) } }

        if (savedInstanceState == null) vm.greet()
        requestPermissions()
        handle(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handle(intent)
    }

    override fun onResume() {
        super.onResume()
        hideSystemStatusBar()
        vm.refreshApps()
        startWakeWord()
    }

    private fun handle(intent: Intent?) {
        when {
            intent?.action == ACTION_WAKE -> vm.startListening()
            // Pressing Home while already home: close panels, like any launcher.
            intent?.action == Intent.ACTION_MAIN && intent.hasCategory(Intent.CATEGORY_HOME) -> vm.setPanel(Panel.None)
        }
    }

    /** The HUD draws its own themed status bar; the system one stays a swipe away. */
    private fun hideSystemStatusBar() {
        WindowCompat.getInsetsController(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.statusBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    private fun requestPermissions() {
        val wanted = buildList {
            add(Manifest.permission.RECORD_AUDIO)
            add(Manifest.permission.READ_CONTACTS)
            add(Manifest.permission.CALL_PHONE)
            add(Manifest.permission.ACCESS_COARSE_LOCATION)
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
        }.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (wanted.isNotEmpty()) permissionRequest.launch(wanted.toTypedArray())
    }

    private fun startWakeWord() {
        val mic = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (mic && vm.settings.picovoiceKey.isNotBlank() && vm.mode.value == Mode.Idle) WakeWordService.ensureStarted(this)
    }

    companion object {
        const val ACTION_WAKE = "jarvis.WAKE"
    }
}
