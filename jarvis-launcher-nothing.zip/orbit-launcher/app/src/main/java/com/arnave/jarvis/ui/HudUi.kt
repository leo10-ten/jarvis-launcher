package com.arnave.jarvis.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.arnave.jarvis.Mode
import com.arnave.jarvis.data.AppEntry
import kotlinx.coroutines.delay
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import kotlin.math.cos
import kotlin.math.sin

object Hud {
    val Bg = Color(0xFF02080D)
    val Cyan = Color(0xFF4FD8FF)
    val CyanDim = Color(0xFF1B6F8A)
    val Panel = Color(0xCC061620)
    val Amber = Color(0xFFFFB547)
    val Text = Color(0xFFCFF6FF)
    val Mono = FontFamily.Monospace
}

@Composable
fun HudTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Hud.Cyan, onPrimary = Hud.Bg, background = Hud.Bg, surface = Hud.Panel,
            onSurface = Hud.Text, onBackground = Hud.Text,
        ),
        content = content,
    )
}

@Composable
fun HudText(
    text: String,
    modifier: Modifier = Modifier,
    size: TextUnit = 12.sp,
    color: Color = Hud.Text,
    weight: FontWeight = FontWeight.Normal,
    maxLines: Int = Int.MAX_VALUE,
) = Text(
    text, modifier,
    style = TextStyle(fontFamily = Hud.Mono, fontSize = size, color = color, fontWeight = weight, letterSpacing = 1.sp),
    maxLines = maxLines, overflow = TextOverflow.Ellipsis,
)

/** Faint grid + vignette behind everything. */
@Composable
fun HudBackground(modifier: Modifier = Modifier) {
    Canvas(modifier.fillMaxSize()) {
        drawRect(Hud.Bg)
        val step = 28.dp.toPx()
        var x = 0f
        while (x < size.width) { drawLine(Hud.Cyan.copy(alpha = 0.04f), Offset(x, 0f), Offset(x, size.height)); x += step }
        var y = 0f
        while (y < size.height) { drawLine(Hud.Cyan.copy(alpha = 0.04f), Offset(0f, y), Offset(size.width, y)); y += step }
        drawRect(Brush.radialGradient(
            listOf(Hud.Cyan.copy(alpha = 0.10f), Color.Transparent),
            center = Offset(size.width / 2, size.height * 0.42f), radius = size.width * 0.9f,
        ))
    }
}

/** Panel with corner brackets, the HUD's basic container. */
@Composable
fun HudFrame(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Box(
        modifier
            .background(Hud.Panel, RoundedCornerShape(4.dp))
            .border(1.dp, Hud.Cyan.copy(alpha = 0.25f), RoundedCornerShape(4.dp))
            .drawBehind {
                val l = 14.dp.toPx(); val w = 2.dp.toPx(); val c = Hud.Cyan
                drawLine(c, Offset(0f, 0f), Offset(l, 0f), w); drawLine(c, Offset(0f, 0f), Offset(0f, l), w)
                drawLine(c, Offset(size.width, size.height), Offset(size.width - l, size.height), w)
                drawLine(c, Offset(size.width, size.height), Offset(size.width, size.height - l), w)
            }
            .padding(12.dp)
    ) { content() }
}

/** The animated core: idles slowly, pulses with your voice, spins up while thinking. */
@Composable
fun HudCore(
    mode: Mode,
    level: Float,
    title: String,
    modifier: Modifier = Modifier,
    onTap: () -> Unit,
    onLongPress: () -> Unit,
) {
    var angle by remember { mutableFloatStateOf(0f) }
    val speed by rememberUpdatedState(
        when (mode) { Mode.Idle -> 14f; Mode.Listening -> 40f; Mode.Thinking -> 170f; Mode.Speaking -> 60f }
    )
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            withFrameNanos { now ->
                if (last != 0L) angle = (angle + speed * (now - last) / 1_000_000_000f) % 360f
                last = now
            }
        }
    }
    val pulse by animateFloatAsState(
        when (mode) { Mode.Listening -> 1f + level * 0.22f; Mode.Speaking -> 1.05f; else -> 1f }, label = "pulse"
    )
    val glow by animateFloatAsState(
        when (mode) { Mode.Idle -> 0.30f; Mode.Listening -> 0.85f; Mode.Thinking -> 0.6f; Mode.Speaking -> 0.7f }, label = "glow"
    )
    val accent = if (mode == Mode.Thinking) Hud.Amber else Hud.Cyan

    Box(
        modifier.pointerInput(Unit) { detectTapGestures(onTap = { onTap() }, onLongPress = { onLongPress() }) },
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val r = size.minDimension / 2f
            rotate(angle) {
                for (i in 0 until 72) {
                    val major = i % 6 == 0
                    ring(0.97f, i * 5f, 2.2f, Hud.Cyan.copy(alpha = if (major) 0.9f else 0.3f), if (major) 7f else 3f, r)
                }
            }
            rotate(-angle * 1.7f) {
                repeat(3) { k -> ring(0.82f, k * 120f, 78f, accent.copy(alpha = 0.8f), 9f, r, round = true) }
            }
            rotate(angle * 2.6f) {
                ring(0.68f, 0f, 290f, Hud.Cyan.copy(alpha = 0.45f), 2.5f, r)
                repeat(24) { i ->
                    val a = Math.toRadians(i * 15.0)
                    val inner = r * 0.60f; val outer = r * 0.64f
                    drawLine(
                        Hud.Cyan.copy(alpha = 0.5f),
                        Offset(center.x + inner * cos(a).toFloat(), center.y + inner * sin(a).toFloat()),
                        Offset(center.x + outer * cos(a).toFloat(), center.y + outer * sin(a).toFloat()),
                        strokeWidth = 2f,
                    )
                }
            }
            val coreR = r * 0.48f * pulse
            drawCircle(
                Brush.radialGradient(listOf(accent.copy(alpha = glow), accent.copy(alpha = glow * 0.25f), Color.Transparent), center, coreR),
                coreR, center,
            )
            drawCircle(accent.copy(alpha = 0.9f), r * 0.40f * pulse, center, style = Stroke(3f))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            HudText(title.uppercase(), size = 20.sp, color = Hud.Text, weight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            HudText(
                when (mode) { Mode.Idle -> "TAP OR SAY MY NAME"; Mode.Listening -> "LISTENING"; Mode.Thinking -> "PROCESSING"; Mode.Speaking -> "RESPONDING" },
                size = 9.sp, color = accent,
            )
        }
    }
}

private fun DrawScope.ring(frac: Float, start: Float, sweep: Float, color: Color, width: Float, r: Float, round: Boolean = false) {
    val rr = r * frac
    drawArc(
        color, start, sweep, useCenter = false,
        topLeft = Offset(center.x - rr, center.y - rr), size = Size(rr * 2, rr * 2),
        style = Stroke(width, cap = if (round) StrokeCap.Round else StrokeCap.Butt),
    )
}

/** The HUD's own status bar, replacing the system one while you're on the home screen. */
@Composable
fun HudStatusBar(battery: Int, charging: Boolean, notifications: Int, wake: String, modifier: Modifier = Modifier) {
    var now by remember { mutableStateOf(LocalTime.now()) }
    LaunchedEffect(Unit) { while (true) { now = LocalTime.now(); delay(1000) } }
    Row(
        modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        HudText(now.format(DateTimeFormatter.ofPattern("HH:mm:ss")), size = 11.sp, color = Hud.Cyan)
        HudText("◆ SYS ONLINE", size = 9.sp, color = Hud.Cyan.copy(alpha = 0.7f))
        Spacer(Modifier.weight(1f))
        HudText(
            when (wake) { "standby" -> "MIC ●"; "paused" -> "MIC ‖"; "no key" -> "MIC ✕"; "error" -> "MIC !"; else -> "MIC ○" },
            size = 9.sp, color = if (wake == "standby") Hud.Cyan else Hud.CyanDim,
        )
        HudText("NTF $notifications", size = 9.sp, color = if (notifications > 0) Hud.Amber else Hud.CyanDim)
        BatteryGauge(battery, charging)
    }
}

@Composable
private fun BatteryGauge(pct: Int, charging: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        val color = when { charging -> Hud.Cyan; pct <= 15 -> Color(0xFFFF5A5A); pct <= 30 -> Hud.Amber; else -> Hud.Cyan }
        Canvas(Modifier.width(28.dp).height(10.dp)) {
            drawRect(color.copy(alpha = 0.5f), style = Stroke(1.5f))
            drawRect(color, topLeft = Offset(2f, 2f), size = Size((size.width - 4f) * pct / 100f, size.height - 4f))
        }
        Spacer(Modifier.width(4.dp))
        HudText("${pct}%${if (charging) "⚡" else ""}", size = 9.sp, color = color)
    }
}

/** Hologram app icon in a targeting ring. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HudAppIcon(app: AppEntry, onOpen: (AppEntry) -> Unit, onLongPress: (AppEntry) -> Unit, modifier: Modifier = Modifier) {
    Column(
        modifier
            .width(76.dp)
            .clip(RoundedCornerShape(8.dp))
            .combinedClickable(onClick = { onOpen(app) }, onLongClick = { onLongPress(app) })
            .padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            Modifier.size(58.dp)
                .border(1.dp, Hud.Cyan.copy(alpha = 0.45f), CircleShape)
                .background(Hud.Cyan.copy(alpha = 0.06f), CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            Canvas(Modifier.fillMaxSize()) {
                drawArc(Hud.Cyan, -60f, 40f, false, style = Stroke(3f, cap = StrokeCap.Round))
                drawArc(Hud.Cyan, 120f, 40f, false, style = Stroke(3f, cap = StrokeCap.Round))
            }
            Image(app.icon, contentDescription = app.label, modifier = Modifier.size(38.dp))
        }
        Spacer(Modifier.height(6.dp))
        HudText(app.label.uppercase(), size = 8.sp, color = Hud.Text.copy(alpha = 0.85f), maxLines = 1)
    }
}
