package com.arnave.jarvis.data

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import android.os.Build
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import java.time.LocalTime

data class AppEntry(
    val label: String,
    val packageName: String,
    val component: ComponentName,
    val icon: ImageBitmap,
)

/** Loads every launchable app and recolours its icon into the HUD's cyan hologram style. */
class AppRepository(private val context: Context) {

    fun loadApps(): List<AppEntry> {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != context.packageName }
            .map { ri ->
                AppEntry(
                    label = ri.loadLabel(pm).toString(),
                    packageName = ri.activityInfo.packageName,
                    component = ComponentName(ri.activityInfo.packageName, ri.activityInfo.name),
                    icon = hologram(ri.loadIcon(pm)).asImageBitmap(),
                )
            }
            .distinctBy { it.component }
            .sortedBy { it.label.lowercase() }
    }

    private fun hologram(drawable: Drawable): Bitmap {
        val size = 144
        // Android 13+: many apps ship a monochrome layer meant for themed icons — use it when present.
        if (Build.VERSION.SDK_INT >= 33 && drawable is AdaptiveIconDrawable) {
            drawable.monochrome?.let { mono ->
                val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(out)
                val inset = -size / 4 // monochrome layers include adaptive-icon padding
                mono.setBounds(inset, inset, size - inset, size - inset)
                mono.colorFilter = PorterDuffColorFilter(HUD_CYAN, PorterDuff.Mode.SRC_IN)
                mono.draw(canvas)
                return out
            }
        }
        // Otherwise map brightness onto cyan so every icon reads as a hologram.
        val src = drawable.toBitmap(size, size, Bitmap.Config.ARGB_8888)
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val r = 0.30f; val g = 0.59f; val b = 0.11f
        val tr = 0.35f; val tg = 0.95f; val tb = 1.15f
        val matrix = ColorMatrix(
            floatArrayOf(
                r * tr, g * tr, b * tr, 0f, 0f,
                r * tg, g * tg, b * tg, 0f, 10f,
                r * tb, g * tb, b * tb, 0f, 25f,
                0f, 0f, 0f, 1f, 0f,
            )
        )
        Canvas(out).drawBitmap(src, 0f, 0f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            colorFilter = ColorMatrixColorFilter(matrix)
        })
        return out
    }

    companion object {
        const val HUD_CYAN = 0xFF4FD8FF.toInt()
    }
}

/** Learns which apps you open at which time of day, for the "suggested now" ring. */
class UsageTracker(context: Context) {
    private val prefs = context.getSharedPreferences("jarvis_usage", Context.MODE_PRIVATE)
    private fun bucket() = LocalTime.now().hour / 3

    fun record(pkg: String) {
        val b = bucket()
        prefs.edit()
            .putInt("$pkg@$b", prefs.getInt("$pkg@$b", 0) + 1)
            .putInt("$pkg@all", prefs.getInt("$pkg@all", 0) + 1)
            .apply()
    }

    fun score(pkg: String): Int = prefs.getInt("$pkg@${bucket()}", 0) * 3 + prefs.getInt("$pkg@all", 0)
}

/** Fuzzy app matching: exact > prefix > word prefix > contains > initials > subsequence. */
object AppMatcher {
    fun score(query: String, label: String): Int {
        val q = query.lowercase().trim()
        val l = label.lowercase()
        if (q.isEmpty()) return 0
        if (l == q) return 100
        if (l.startsWith(q)) return 80
        if (l.split(' ', '-', '_').any { it.startsWith(q) }) return 60
        if (l.contains(q)) return 40
        val initials = l.split(' ').filter { it.isNotEmpty() }.joinToString("") { it.take(1) }
        if (q.length >= 2 && initials.startsWith(q)) return 30
        var i = 0
        for (c in l) if (i < q.length && c == q[i]) i++
        return if (i == q.length && q.length >= 3) 10 else 0
    }

    fun rank(query: String, apps: List<AppEntry>): List<AppEntry> =
        if (query.isBlank()) emptyList()
        else apps.map { it to score(query, it.label) }
            .filter { it.second > 0 }
            .sortedByDescending { it.second }
            .map { it.first }

    fun best(name: String, apps: List<AppEntry>): AppEntry? =
        apps.firstOrNull { it.label.equals(name.trim(), ignoreCase = true) } ?: rank(name, apps).firstOrNull()
}
