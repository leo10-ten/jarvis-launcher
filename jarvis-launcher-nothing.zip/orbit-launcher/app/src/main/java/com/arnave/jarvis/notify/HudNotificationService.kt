package com.arnave.jarvis.notify

import android.app.Notification
import android.app.PendingIntent
import android.content.Context
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.core.app.NotificationManagerCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

data class HudNotification(
    val key: String,
    val app: String,
    val title: String,
    val text: String,
    val time: Long,
    val contentIntent: PendingIntent?,
)

/** Shared between the listener service and the HUD's own notification panel. */
object NotificationStore {
    internal val _items = MutableStateFlow<List<HudNotification>>(emptyList())
    val items = _items.asStateFlow()
    internal var service: HudNotificationService? = null

    fun isAccessGranted(context: Context) =
        NotificationManagerCompat.getEnabledListenerPackages(context).contains(context.packageName)

    /** Short version for reading aloud: newest five, grouped as "App: title". */
    fun spokenDigest(): String = items.value.take(5).joinToString(". ") {
        "${it.app}: ${it.title.ifBlank { it.text }}".take(90)
    }.let { if (items.value.size > 5) "$it. And ${items.value.size - 5} more." else it }

    fun dismiss(key: String) = service?.cancelNotification(key)
    fun dismissAll() = service?.cancelAllNotifications()

    /** Plain-text digest the assistant can read out or summarise. */
    fun digest(limit: Int = 12): String = items.value.take(limit).joinToString("\n") {
        "- ${it.app}: ${it.title} — ${it.text}".take(200)
    }.ifEmpty { "(no notifications)" }
}

class HudNotificationService : NotificationListenerService() {

    override fun onListenerConnected() {
        NotificationStore.service = this
        refresh()
    }

    override fun onListenerDisconnected() {
        NotificationStore.service = null
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) = refresh()
    override fun onNotificationRemoved(sbn: StatusBarNotification?) = refresh()

    private fun refresh() {
        val list = runCatching { activeNotifications }.getOrNull().orEmpty()
            .filter { !it.isOngoing && (it.notification.flags and Notification.FLAG_GROUP_SUMMARY) == 0 }
            .mapNotNull { sbn ->
                val extras = sbn.notification.extras
                val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
                val text = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
                    ?: extras.getCharSequence(Notification.EXTRA_TEXT))?.toString().orEmpty()
                if (title.isBlank() && text.isBlank()) return@mapNotNull null
                HudNotification(
                    key = sbn.key,
                    app = appLabel(sbn.packageName),
                    title = title,
                    text = text,
                    time = sbn.postTime,
                    contentIntent = sbn.notification.contentIntent,
                )
            }
            .sortedByDescending { it.time }
        NotificationStore._items.value = list
    }

    private fun appLabel(pkg: String): String = runCatching {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    }.getOrDefault(pkg)
}
